==============
tornado-celery
==============

tornado-celery is a non-blocking `Celery`_ client for `Tornado`_

.. _Celery: http://celeryproject.org
.. _Tornado: http://tornadoweb.org

Contents
========

.. toctree::
    :maxdepth: 2

   install
   usage
   api

tornado-celery is Open Source and licensed under the `BSD License`_.

.. _`BSD License`: http://www.opensource.org/licenses/BSD-3-Clause

