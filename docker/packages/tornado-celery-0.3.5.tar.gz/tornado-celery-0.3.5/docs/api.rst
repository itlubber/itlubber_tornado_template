API Reference
--------------

.. toctree::
   :maxdepth: 2

.. autotornado:: tcelery.app:Application()

