Installation
------------

To install, simply: ::

    $ pip install tornado-celery
